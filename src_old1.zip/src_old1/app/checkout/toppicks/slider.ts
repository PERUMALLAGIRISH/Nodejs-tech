export interface Slider {
  image: string;
  alt: string;
}

export class slider implements Slider {
  constructor(public image: string, public alt: string) {}
}
