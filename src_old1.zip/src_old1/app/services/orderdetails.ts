export interface IProduct {
  OrderNumber: number;
  CustomerName: string;
  Description: string;
  OrderStatus: string;
  DatePlaced: string;
  OrderTotal: string;
}
