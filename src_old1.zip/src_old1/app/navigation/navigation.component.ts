import { Component, OnInit } from "@angular/core";
import { DeviceDetectorService } from "ngx-device-detector";
import { CategoriesService } from "./categories.service";
import { Category } from "./category";
import { ProductserviceService } from "../services/product.services";

@Component({
  selector: "app-navigation",
  templateUrl: "./navigation.component.html",
  styleUrls: ["./navigation.component.css"]
})
export class NavigationComponent implements OnInit {  
  errorMessage: any;
  categoriesList: Category[];
  isShow: boolean = true;
  currentSubCatName: string;
  currentSubCatImage:string;
  isMobile: boolean = false;

  constructor(
    private categoriesService: CategoriesService,
    private deviceService: DeviceDetectorService
  ) {}

  ngOnInit() {
    this.isShow = false;
    this.isMobile = this.deviceService.isMobile();
    this.categoriesService.getCategories().subscribe(
      data => {
        this.categoriesList = data;
        this.currentSubCatImage = this.categoriesList[0]['image'];
      },
      error => (this.errorMessage = <any>error)
    );
       
  }
  showHideParentImage($event, nameValue,imageValue) {
    this.currentSubCatName = nameValue;
    this.currentSubCatImage = imageValue;
  }
  showHideChildImage($event, nameValue,imageValue) {
    this.currentSubCatName = nameValue;
    this.currentSubCatImage = imageValue;
  }
}
