import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Iuser } from "../user/user";

//database Connection
// import * as firebase from "firebase";
// import firestore from "firebase/firestore";

import { Observable } from "rxjs";
import { map } from "rxjs/operators";

@Injectable({
  providedIn: "root"
})
export class UserserviceService {
  userList: Iuser;
 // dbUsers = firebase.firestore().collection("userData");

  constructor(private http: HttpClient) {}

  // getData() {
  //   return this.http.get<Iuser[]>("../assets/json/products.json");
  // }

  /*
  getUserList(): Observable<any> {
    return new Observable(observer => {
      this.dbUsers.onSnapshot(querySnapshot => {
        let user = [];
        querySnapshot.forEach(doc => {
          let data = doc.data();
          user.push({
            userId: doc.id,
            fname: data.fname,
            lname: data.lname,
            email: data.email,
            phNumber: data.phNumber,
            addressLineOne: data.addressLineOne,
            addressLineTwo: data.addressLineTwo,
            city: data.city,
            state: data.state,
            zipCode: data.zipCode,
            country: data.country,
            password: data.password,
            termsAndCondition: data.termsAndCondition
          });
        });
        observer.next(user);
      });
    });
  }

  checkExist(email: string) {
    let userNames = [];
    this.dbUsers.onSnapshot(querySnapshot => {
      querySnapshot.forEach(doc => {
        let data = doc.data();
        userNames.push(data.email);
      });
    });

    //console.log(userNames.indexOf(`"{{email}}"`) !== -1);
    return false;
  }
  createUser(user): Observable<any> {
    console.log(user);
    return new Observable(observer => {
      this.dbUsers.add(user).then(doc => {
        observer.next({
          key: doc.id
        });
      });
    });
  }

  deleteBoards(id: string): Observable<{}> {
    return new Observable(observer => {
      this.dbUsers
        .doc(id)
        .delete()
        .then(() => {
          observer.next();
        });
    });
  } */
}
