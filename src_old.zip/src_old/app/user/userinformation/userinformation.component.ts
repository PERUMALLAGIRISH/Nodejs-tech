import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute  } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '../../../../node_modules/@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { OrderService } from '../../services/order.service';
import { IProduct } from '../../services/orderdetails';
import {PageChangedEvent}from 'ngx-bootstrap/pagination';
@Component({ 
  selector: 'app-userinformation',
  templateUrl: './userinformation.component.html',
  styleUrls: ['./userinformation.component.css'],
  providers: [OrderService]
})
export class UserinformationComponent implements OnInit {

  constructor(private router:Router,private formBuilder: FormBuilder,private toastr: ToastrService,private orderService:OrderService,private route: ActivatedRoute) {
    this.filteredProducts = this.orderdetails;
    this.listFilter ='';
   }
   userInfoType: string;
  /*Account Information
  Name: Pradeep.M
  Date: 24-01-2019*/
  currentUserEmail: string;
  isLoggedIn: boolean;
  updatedCartall: any;
  updatedCartList: any;
  currentUser:any;
  /*Change Password
  Name: Pradeep.M
  Date: 24-01-2019*/
  changePasswordForm: FormGroup;
  submitted = false;
  loggedIn = false;
  msg: string = null;
  userEmail = localStorage["logedUserEmail"];
  /*Address Book
  Name: Pradeep.M
  Date: 25-01-2019*/
  addressForm: FormGroup;
  addresses: any;
  addressEditForm: FormGroup;
  formdata = [];
  userName:string;
  alphaNumaric = "^[A-Za-z0-9_]{3,50}$";
  numberonlyPhone = "^[0-9]{10,10}$";
  numberonlyZipCode = "^[0-9]{6,6}$";
  editAddress: any;
  submittedAddress = false;
  /*Order History
  Name: Pradeep.M
  Date: 25-01-2019*/
  orderdetails:IProduct[];
  detailsservice: any;
  data: IProduct[]=[];
  contentArray = new Array().fill('');
  items:IProduct[];
  totalItems:number;
  _listFilter: string;
  get listFilter(): string{
    return this._listFilter;
  }
  set listFilter(value:string) {
    this._listFilter = value;
    this.data= this.listFilter ? this.performFilter(this.listFilter) : this.orderdetails;
  } 
  filteredProducts: IProduct[];
    products:IProduct[]=[];
    /*View Order History
    Name: Pradeep.M
    Date: 24-01-2019*/
    orderDetail: any;
    id: number;
  /*Navigations Flags for User Information
  Name: Pradeep.M
  Date: 24-01-2019*/
  accountDetailsFlag:any;
  manageDetailsFlag:any;
  addressDetailsFlag:any;
  orderDetailsFlag:any;
  viewDetailsFlag:any;
  ngOnInit() {
    //document.getElementById("navbar").style.display = "block";
    this.route.params.subscribe(params =>
      {
        this.userInfoType=params['id'];
        this.accountDetailsFlag=this.userInfoType == 'AccountDetails' ? "1": " 0";
        this.manageDetailsFlag=this.userInfoType == 'ManagePassword' ? "1": " 0";
        this.addressDetailsFlag=this.userInfoType == 'AddressBook' ? "1": " 0";
        this.orderDetailsFlag=this.userInfoType == 'OrderHistory' ? "1": " 0";
        this.submitted      =this.userInfoType == 'ManagePassword' ? false:true;
        this.submittedAddress =this.userInfoType == 'AddressBook' ? false:true;
  //  document.getElementById(this.userInfoType).scrollIntoView({behavior: "smooth", block: "end", inline: "nearest"});  
    })
      
    /*Fetch Local Storage Values*/
    if (!localStorage.getItem("logedUser")) {
      this.router.navigateByUrl("/");
    }
      this.currentUserEmail =localStorage.getItem("logedUserEmail");
      this.currentUser= JSON.parse(localStorage.getItem(this.currentUserEmail))[0];
     
      /* Change Password  
      Name: Pradeep.M
      Date: 24-01-2019*/
      this.changePasswordForm = this.formBuilder.group({
        oldPassword: ['', [Validators.required, Validators.minLength(6)]],
        newPassword: ['', [Validators.required, Validators.minLength(6)]],
        confirmPassword: ['', Validators.required]
      }, {
        validator:this.matchValidator('newPassword','confirmPassword')
      });
      /*Address Book Changes
      Name: Pradeep.M
      Date: 25-01-2019*/ 
      this.addressForm = this.formBuilder.group(
        {
          firstName: [
            "",
            [Validators.required, Validators.pattern(this.alphaNumaric)]
          ],
          lastName: [
            "",
            [Validators.required, Validators.pattern(this.alphaNumaric)]
          ],
          PhoneNumber: [
            "",
            [Validators.required, Validators.pattern(this.numberonlyPhone)]
          ],
          cityName: [
            "",Validators.required
          ],
          stateName: [
            "",Validators.required
          ],
          streetName: [
            "",Validators.required
          ],
          countryName: [
            "",Validators.required
          ],
          zipCode: [
            "",
            [Validators.required, Validators.pattern(this.numberonlyZipCode)]
          ]
        }
      );
      this.addressEditForm = this.formBuilder.group(
        {
          firstName: [
            "",
            [Validators.required, Validators.pattern(this.alphaNumaric)]
          ],
          lastName: [
            "",
            [Validators.required, Validators.pattern(this.alphaNumaric)]
          ],
          PhoneNumber: [
            "",
            [Validators.required, Validators.pattern(this.numberonlyPhone)]
          ],
          cityName: [
            "",Validators.required
          ],
          stateName: [
            "",Validators.required
          ],
          streetName: [
            "",Validators.required
          ],
          countryName: [
            "",Validators.required
          ],
          zipCode: [
            "",
            [Validators.required, Validators.pattern(this.numberonlyZipCode)]
          ]
        }
      );
      
      this.addresses = JSON.parse(localStorage[this.userEmail]);
      console.log(this.addresses)
      this.addresses = this.addresses.filter(function (el) {
        return el != null;
      });
      
     this.userName = this.addresses[0].firstName;
     /*Order History
      Name: Pradeep.M
      Date: 25-01-2019*/
      this.orderdetails =this.currentUser["orderData"]['orders'];
      this.contentArray = this.orderdetails;
      this.orderdetails=this.contentArray.slice(0,4);
       console.log(this.orderdetails);
    }
    /* Change Password validation 
       Name: Pradeep.M
       Date: 24-01-2019*/
    get f() {
      if(this.userInfoType == 'ManagePassword' || this.manageDetailsFlag == 1)
      {
        return this.changePasswordForm.controls;
      }
      else if(this.userInfoType == 'AddressBook' || this.addressDetailsFlag == 1)
      {
        return this.addressForm.controls;
      }
    }
    
    matchValidator(controlName: string, matchingControlName: string) {
      return (formGroup: FormGroup) => {
        const control = formGroup.controls[controlName];
        const matchingControl = formGroup.controls[matchingControlName];
  
        if (matchingControl.errors && !matchingControl.errors.mustMatch) {
            return;
        }
        if (control.value !== matchingControl.value) {
            matchingControl.setErrors({ match: true });
        } else {
            matchingControl.setErrors(null);
        } 
      }
    }
    redirecttype(type) 
    {
      this.submitted=type == 'ManagePassword' ? false:true;
      this.submittedAddress=type == 'AddressBook' ? false:true;
      if(type == 'OrderHistory')
      {
        this.orderDetailsFlag = 1;
      }
      this.viewDetailsFlag = 0;
      console.clear();
     console.log(type);
      this.router.navigate(['/customer', type]);
    }
    /*Chage Password form submit
    Name: Pradeep.M
    Date: 24-01-2019*/
    onSubmit() {
      this.submitted = true;
      this.loggedIn = true;
      if (this.changePasswordForm.invalid) {
        return;
      }
      let oldPassword = JSON.parse(localStorage.getItem(this.userEmail))[0].password;
      if(oldPassword != this.changePasswordForm.value.oldPassword) {
        this.toastr.error('Old password is not correct.');
      }
      else {
        let customerAll = JSON.parse(localStorage.getItem(this.userEmail));
        let usercustomerAll = JSON.parse(localStorage.getItem("userDatas"));
        customerAll[0].password = this.changePasswordForm.value.newPassword;
        customerAll[0].confirmPassword = this.changePasswordForm.value.newPassword;
        usercustomerAll[0].password = this.changePasswordForm.value.newPassword;
        usercustomerAll[0].confirmPassword = this.changePasswordForm.value.newPassword;
        localStorage.setItem(
          this.userEmail,
          JSON.stringify(customerAll)
        );
        localStorage.setItem(
          "userDatas",
          JSON.stringify(usercustomerAll)
        );
        this.toastr.success('Password changed successfully.');
      }            
    }
    /*Address Book Changes
      Name: Pradeep.M
      Date: 25-01-2019*/
    editaddress(value) {
      this.editAddress = this.addresses[value];   
      this.addressEditForm.setValue(this.editAddress);
    }
  
    deleteaddress(value) {
      var datas = localStorage[this.userEmail];
      datas = JSON.parse(datas);
      datas[value] = []; 
      datas.splice(value, 1);
      localStorage[this.userEmail] = JSON.stringify(datas);
      this.addresses = JSON.parse(localStorage[this.userEmail]);
    }
    onSubmitAddress(){
      this.submittedAddress = true;
  
      //stop here if form is invalid
      if (this.addressForm.invalid) {
        return;
      }
  
      var datas = localStorage[this.userEmail];
      //check local storage is empty
      if (datas !== undefined) {
        datas = JSON.parse(datas);
        datas.push(this.addressForm.value);
        localStorage[this.userEmail] = JSON.stringify(datas);
      } else {
        this.formdata.push(this.addressForm.value);
        localStorage[this.userEmail] = JSON.stringify(this.formdata);
      }
      var element = document.getElementById("closeAddress"); 
      element.click();
      this.addresses = JSON.parse(localStorage[this.userEmail]);
      this.toastr.success("You have successfully added new address.");
    }    
    onUpdate(value) {
      var datas = localStorage[this.userEmail];
      datas = JSON.parse(datas);
      datas[value] = this.addressEditForm.value;
      localStorage[this.userEmail] = JSON.stringify(datas);
      var element = document.getElementById("closeEditAddress-"+value); 
      element.click();
      this.addresses = JSON.parse(localStorage[this.userEmail]);
      this.toastr.success("You have successfully updated the address.");
    }
    /*Order History
      Name: Pradeep.M
      Date: 25-01-2019*/
      performFilter(filterBy: string) : IProduct[] {
        filterBy = filterBy.toLocaleLowerCase();
        return this.orderdetails.filter((product: IProduct) =>
         product.DatePlaced.toLocaleLowerCase().indexOf(filterBy) !== -1);
       }
       pageChanged(event:PageChangedEvent):void{
        const startItem = (event.page -1) * event.itemsPerPage;
        const endItem = event.page * (event.itemsPerPage);
        this.orderdetails = this.contentArray.slice(startItem, endItem);
      }
      viewOrder(type,value)
      {
        this.orderDetail =this.currentUser["orderData"]['orders'][value];
        this.viewDetailsFlag=1;
        this.orderDetailsFlag=0;
      }
}
