import { Component, OnInit } from '@angular/core';
import { ActivatedRoute }     from '@angular/router';

@Component({
  selector: 'app-order-history',
  templateUrl: './order-history.component.html',
  styleUrls: ['./order-history.component.css']
})
export class OrderHistoryComponent implements OnInit {
  orderDetail: any;
  currentUser = localStorage.getItem("logedUserEmail");
  id: number;
  constructor(private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.id = params['id'];
      this.orderDetail =JSON.parse(localStorage.getItem(this.currentUser))[0]["orderData"]['orders'][this.id];
    });
    console.log(this.orderDetail);
  }
}