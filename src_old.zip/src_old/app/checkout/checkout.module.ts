import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CheckoutComponent } from './checkout.component';
import { CartComponent } from './cart/cart.component';
import { SuccessComponent } from "./success/success.component";
import{OrderListComponent} from './order-list/order-list.component';
import { HttpClientModule } from '@angular/common/http';
import { PaginationModule } from "ngx-bootstrap/pagination";
import { BsDropdownModule } from "ngx-bootstrap/dropdown";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { AppRoutingModule } from '../app-routing.module';
import {OrderHistoryComponent} from './order-history/order-history.component';
import { ToppicksComponent } from './toppicks/toppicks.component';

@NgModule({
  declarations: [
    CheckoutComponent, CartComponent,SuccessComponent, OrderListComponent,OrderHistoryComponent,ToppicksComponent
  ],
  imports: [
    CommonModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    PaginationModule.forRoot(),
    BsDropdownModule.forRoot(),
    ToastrModule.forRoot(),
    AppRoutingModule
  ]
})
export class CheckoutModule { }
