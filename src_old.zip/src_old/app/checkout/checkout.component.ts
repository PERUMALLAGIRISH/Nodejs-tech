import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { CartProduct } from './cart/cart';
import { CartService } from './cart/cart.service';
import { Router } from "@angular/router";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {
  checkoutForm: FormGroup;
  addressForm: FormGroup;
  registerForm: FormGroup;
  loading = false;
  submitted = false;
  addsubmitted = false;
  returnUrl: string;
  price: number;
  total: number;
  itemtotal: number;
  cartList: CartProduct[];
  updatedcartList: any;
  shipdata:any = [];
  data:any = [];
  shippingCharge: number;
  errorMessage: any;
  isCollapsed = false;
  htmlToAdd ="";
  showIcons = true;
  showNewAddr = false;
  default: string;
  currentUser = localStorage.getItem("logedUserEmail");
  shipMethodname:string;
  orderId:number;
  granttotal:string;
  datePlace= new Date();
  customerAddress: any;
  alphaNumaric = "^[A-Za-z0-9_]{3,50}$";
  numberonlyPhone = "^[0-9]{10,10}$";
  numberonlyZipCode = "^[0-9]{6,6}$";
  formdata = [];
  length: any;
  newddress: any;
  private show:boolean=true;
  constructor(
    private formBuilder: FormBuilder,
    private cartService: CartService,
    public toastr: ToastrService,
    private http: HttpClient,
    private router: Router)
  { }

  ngOnInit() {
    if (!localStorage.getItem("logedUser")) {
      this.router.navigateByUrl("/");
    }
    document.getElementById("navbar").style.display = "none";
    // localStorage.removeItem("checkoutaddress");
    this.orderId = Math.floor(100000 + Math.random() * 900000);
    this.checkoutForm = this.formBuilder.group({
      shipaddress: ['', Validators.required],
      shipmethod:[''],
      shipMethodname:[''],
      shipAmount:[''],
      orderId:[''],
      subTotal:[''],
      grantTotal:[''],
      datePlace:[''],
      payment: ['', Validators.required]
    });   
    this.addressForm = this.formBuilder.group({
      firstName: [
        "",
        [Validators.required, Validators.pattern(this.alphaNumaric)]
      ],
      lastName: [
        "",
        [Validators.required, Validators.pattern(this.alphaNumaric)]
      ],
      phoneNumber: [
        "",
        [Validators.required, Validators.pattern(this.numberonlyPhone)]
      ],
      cityName: [
        "",Validators.required
      ],
      stateName: [
        "",Validators.required
      ],
      streetName: [
        "",Validators.required
      ],
      countryName: [
        "",Validators.required
      ],
      zipCode: [
        "",
        [Validators.required, Validators.pattern(this.numberonlyZipCode)]
      ]
    });
    this.http.get('../assets/json/shipping.json').subscribe(
      shipdata => {
        this.shipdata = shipdata as string [];
        this.price = shipdata[0]['price'];
        this.shipMethodname = shipdata[0]['shippingname'];
      }
    );
    this.customerAddress =  JSON.parse(localStorage.getItem(this.currentUser));
    this.length = this.customerAddress.length;
    this.cartService.getCarts().subscribe(
      data => {
        this.cartList = data;
        this.updatedcartList = JSON.parse(localStorage.getItem(this.currentUser))[0].cartData;
        if (!this.updatedcartList['subTotal']){
          this.router.navigate(['/']);
        }
        this.shippingCharge = this.updatedcartList['shippingCharge'];
        if (this.shippingCharge != 0) {
          this.price = this.shippingCharge;
        }
        this.itemtotal = this.updatedcartList['subTotal'];
        this.updatedcartList['grandTotal'] = this.updatedcartList['subTotal'] + this.price;
      },
      error => this.errorMessage = <any>error
    );
    this.default= "20-UPS";
    if (JSON.parse(localStorage.getItem(this.currentUser))[0].cartData.shippingCharge ) {
      this.default = JSON.parse(localStorage.getItem(this.currentUser))[0].cartData.shippingCharge+"-"+JSON.parse(localStorage.getItem(this.currentUser))[0].cartData.shippingMethod;
      console.log(this.default);
    } 
    this.checkoutForm.controls['shipmethod'].setValue(this.default, {onlySelf: true});
  }
  get f() { return this.checkoutForm.controls; }
  get g() { return this.addressForm.controls; }

  onSubmit(){
    
    this.submitted = true;
    var orderData = [];
    var orderInfo = this.checkoutForm.value;
    let idval;
    var genValue = false;
    idval = document.getElementsByName('shipaddress');
    for(var i=0; i<idval.length;i++){
            if(idval[i].checked == true){
                genValue = true;    
            }
        }
        if(!genValue){
            document.getElementById('radiobtnValidation').style.display="block";
            return false;
        }

    // idval=document.getElementById('radioBtn');
    // if(idval.checked == false)
    // {
    //   document.getElementById('radiobtnValidation').innerHTML="Select the Address";
    //   return false;
    // }
       
    if (this.checkoutForm.invalid){
      return;
    }
    if (localStorage.getItem("logedUser")) {
      var UserData = JSON.parse(localStorage.getItem(this.currentUser));
      if (UserData[0]["orderData"]) {
        orderData = UserData[0]["orderData"]["orders"];
      }
      var productData = UserData[0]["cartData"]["productData"];
      if (localStorage.getItem("checkoutaddress")) {
        UserData.push(this.addressForm.value);
        localStorage.setItem(this.currentUser, JSON.stringify(UserData));
      }
      this.newddress =  JSON.parse(localStorage.getItem(this.currentUser));
      var addr = this.newddress[orderInfo.shipaddress];
      orderData.push({orderInfo,productData,addr});

      var order = {
        orders: orderData,
      }
      UserData[0]["orderData"] = order;
      localStorage.setItem(this.currentUser, JSON.stringify(UserData));
      localStorage.setItem("lastOrder", JSON.stringify({orderInfo,productData,addr}));
      localStorage.removeItem("checkoutaddress");
      this.router.navigate(["/success"]);
    }
  }
  callType(value){
    let shipAmnt = value.split("-");
    let currentUser = localStorage.getItem("logedUserEmail");
    let updatedCartall = JSON.parse(localStorage.getItem(currentUser));
    updatedCartall[0].cartData.shippingCharge = Number(shipAmnt[0]);
    updatedCartall[0].cartData.shippingMethod = shipAmnt[1];
    updatedCartall[0].cartData.grandTotal = this.itemtotal + Number(shipAmnt[0]);
    localStorage.setItem(
      currentUser,
      JSON.stringify(updatedCartall)
    );
    this.updatedcartList['shippingCharge'] = shipAmnt[0];
    this.updatedcartList['grandTotal'] = this.itemtotal + Number(shipAmnt[0]);
    this.price = shipAmnt[0];
    this.shipMethodname = shipAmnt[1];
  }
  saveAddress(){  
    this.addsubmitted = true;
    this.htmlToAdd = "";
    var addrinfo = this.addressForm.value;
    if (this.addressForm.invalid) {
      return;
    }
    if (localStorage.getItem("checkoutaddress")) {
      localStorage.removeItem("checkoutaddress");
    }
    localStorage.setItem("checkoutaddress", JSON.stringify(addrinfo));
    this.showIcons = false;
    this.showNewAddr = true;
    this.htmlToAdd += '<p class="mt-3">'+ addrinfo.firstName+' '+addrinfo.lastName+'</p>'+ addrinfo.phoneNumber+'<p></p><p>Address: '+ addrinfo.streetName+' '+addrinfo.cityName+' '+addrinfo.stateName+' '+addrinfo.countryName+' '+addrinfo.zipCode+'</p>';
    var element = document.getElementById("closeAddress"); 
    element.click();
    this.toastr.success("Address has been saved");
  }
 
  toggle(){

     document.getElementById('radiobtnValidation').style.display = "none"; 
}
}
