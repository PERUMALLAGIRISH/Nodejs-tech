import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from '../../../../node_modules/rxjs';
import { CartProduct } from './cart';

@Injectable({
    providedIn: 'root'
  })

export class CartService  {

  private cartUrl = './assets/json/cart.json';
  constructor(private httpService: HttpClient) { }

  getCarts(): Observable<CartProduct[]> {
    return this.httpService.get<CartProduct[]>(this.cartUrl);
  }

}
