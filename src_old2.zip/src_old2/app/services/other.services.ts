import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable, throwError } from "rxjs";
import { Slider } from "../home/slider";

@Injectable({
  providedIn: "root"
})
export class OtherService {
  private sliderUrl = "../assets/json/images.json";
  private categoryUrl = "../assets/json/category.json";
  constructor(private http: HttpClient) {}

  getSlider(): Observable<Slider[]> {
    return this.http.get<Slider[]>(this.sliderUrl);
  }
  getCategory(): Observable<Slider[]> {
    return this.http.get<Slider[]>(this.categoryUrl);
  }
}
