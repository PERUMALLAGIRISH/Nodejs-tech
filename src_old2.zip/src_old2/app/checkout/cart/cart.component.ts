import { Component, OnInit } from "@angular/core";
import { CartProduct } from "./cart";
import { CartService } from "./cart.service";
import { ToastrService } from "ngx-toastr";
import { Router } from "@angular/router";

@Component({
  selector: "app-cart",
  templateUrl: "./cart.component.html",
  styleUrls: ["./cart.component.css"]
})
export class CartComponent implements OnInit {
  cartList: CartProduct[];
  updatedCartList: any;
  updatedCartall: any;
  errorMessage: any;
  currentUser: string;
  isLoggedIn: boolean;
  constructor(
    private cartService: CartService,
    private toastr: ToastrService,
    private router: Router
  ) {}

  ngOnInit() {
    if (localStorage.getItem("logedUser")) {
      this.isLoggedIn = true;
      this.currentUser = localStorage.getItem("logedUserEmail");
      this.updatedCartall = JSON.parse(localStorage.getItem(this.currentUser));
      this.updatedCartList = this.updatedCartall[0].cartData;
      if (this.updatedCartList.productData.length <= 0) {
        this.router.navigateByUrl("/");
        this.toastr.warning("cart is empty");
      }
    } else {
      this.isLoggedIn = false;
      this.router.navigateByUrl("/");
    }
  }

  minusQty(event) {
    var updatedValue: number;
    var updatedTotalQty: number = 0;
    var updatedTotalPrice: number = 0;
    var minQty = 1;
    var id = event.target.id;
    var value = (<HTMLInputElement>document.getElementById("qty-" + id)).value;
    if (parseInt(value) && !isNaN(parseInt(value))) {
      updatedValue = parseInt(value) - 1;
      if (updatedValue >= minQty) {
        this.updatedCartList.productData[id].quantity = updatedValue;
        this.updatedCartList.productData[id].price =
          updatedValue *
          parseInt(this.updatedCartList.productData[id].productPrice);
        this.updatedCartList.productData.forEach(element => {
          updatedTotalQty += parseInt(element.quantity);
          updatedTotalPrice += element.price;
        });
        this.updatedCartList.totalQuantity = updatedTotalQty;
        this.updatedCartList.subTotal = updatedTotalPrice;
        this.updatedCartList.grandTotal =
          this.updatedCartList.subTotal + this.updatedCartList.shippingCharge;
        localStorage.setItem(
          this.currentUser,
          JSON.stringify(this.updatedCartall)
        );
        document.querySelector(
          "#miniCart span"
        ).innerHTML = this.updatedCartList.totalQuantity;
      } else {
        this.toastr.error("Cann't add more than 5 Quantity and less than 1");
      }
    } else {
      this.toastr.error("Cann't add more than 5 Quantity and less than 1");
    }
  }
  plusQty(event) {
    var updatedValue: number;
    var updatedTotalQty: number = 0;
    var updatedTotalPrice: number = 0;
    var maxQty = 5;
    var id = event.target.id;
    var value = (<HTMLInputElement>document.getElementById("qty-" + id)).value;
    if (parseInt(value) && !isNaN(parseInt(value))) {
      updatedValue = parseInt(value) + 1;
      if (updatedValue <= maxQty) {
        this.updatedCartList.productData[id].quantity = updatedValue;
        this.updatedCartList.productData[id].price =
          updatedValue *
          parseInt(this.updatedCartList.productData[id].productPrice);
        this.updatedCartList.productData.forEach(element => {
          updatedTotalQty += parseInt(element.quantity);
          updatedTotalPrice += element.price;
        });
        this.updatedCartList.totalQuantity = updatedTotalQty;
        this.updatedCartList.subTotal = updatedTotalPrice;
        this.updatedCartList.grandTotal =
          this.updatedCartList.subTotal + this.updatedCartList.shippingCharge;
        localStorage.setItem(
          this.currentUser,
          JSON.stringify(this.updatedCartall)
        );
        document.querySelector(
          "#miniCart span"
        ).innerHTML = this.updatedCartList.totalQuantity;
      } else {
        this.toastr.error("Cann't add more than 5 Quantity and less than 1");
      }
    } else {
      this.toastr.error("Cann't add more than 5 Quantity and less than 1");
    }
  }
  deleteCart(event) {
    var updatedTotalQty: number = 0;
    var updatedTotalPrice: number = 0;
    var id = event.target.id;
    this.updatedCartList.productData.splice(id, 1);
    this.updatedCartList.productData.forEach(item => {
      updatedTotalQty += parseInt(item.quantity);
      updatedTotalPrice += item.price;
    });
    this.updatedCartList.totalQuantity = updatedTotalQty;
    this.updatedCartList.subTotal = updatedTotalPrice;
    this.updatedCartList.grandTotal =
      this.updatedCartList.subTotal + this.updatedCartList.shippingCharge;
    localStorage.setItem(this.currentUser, JSON.stringify(this.updatedCartall));
    if (this.updatedCartall[0].cartData.totalQuantity == 0) {
      var item = document.querySelector("#miniCart span");
      item.parentNode.removeChild(item);
    } else {
      document.querySelector(
        "#miniCart span"
      ).innerHTML = this.updatedCartList.totalQuantity;
    }
  }
  shopBtnClick() {
    this.router.navigateByUrl("/");
  }
  checkoutBtnClick() {
    this.router.navigateByUrl("/checkout");
  }
}
