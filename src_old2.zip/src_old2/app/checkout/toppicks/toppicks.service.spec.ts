import { TestBed } from "@angular/core/testing";

import { ToppicksService } from "./toppicks.service";

describe("ToppicksService", () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it("should be created", () => {
    const service: ToppicksService = TestBed.get(ToppicksService);
    expect(service).toBeTruthy();
  });
});
